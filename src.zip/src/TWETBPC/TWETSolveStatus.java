package TWETBPC;

/**
 * 求解流程的高层状态枚举。
 * <p>
 * 这里的状态定义目前偏“原型框架语义”：
 * 用来说明树搜索骨架推进到了哪个阶段，
 * 而不是严格等价于“最优已证明 / 不可行已证明”这类精确求解语义。
 */
public enum TWETSolveStatus {
	/** 仅完成对象初始化，还没有真正处理节点。 */
	INITIALIZED,
	/** 至少已经处理到根节点。 */
	ROOT_PROCESSED,
	/** 树搜索框架结束。 */
	FINISHED,
	/** 流程异常结束。 */
	FAILED
}
